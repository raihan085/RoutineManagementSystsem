<!DOCTYPE html>
<html lang="en">
<head>
  @include('Web.Auth.Partials.CSS')
</head>
<body>


@include('Web.Auth.Layouts.LogInNav')

@include('Web.Auth.includes.signup')


@include('Web.Auth.Partials.footer')
@include('Web.Auth.Partials.JS')
</body>
</html>
