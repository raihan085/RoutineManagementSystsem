
<div class="alert alert-success alert-dismissible mx-3">
  <button type="button" class="close" data-dismiss="alert">&times;</button>
    <h6 class="text-dark">Your Request is pending.Please try some moment</h6>
</div>
