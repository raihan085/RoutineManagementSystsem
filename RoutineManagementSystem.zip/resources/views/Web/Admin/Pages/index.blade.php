<!DOCTYPE html>
<html lang="en">
<head>
  @include('Web.Admin.Partials.CSS')

  <link rel="stylesheet" href="{{ asset('Web/css/Admin/style.css') }}">


</head>
<body>

  @include('Web.Admin.layout.AdminnavBar')
  @include('Web.Admin.Partials.JS')

</body>
</html>
