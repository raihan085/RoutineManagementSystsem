@extends('Web.Admin.Pages.index')

@section('body')


@endsection
