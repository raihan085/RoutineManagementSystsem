<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Routine Management System</title>
<link rel="icon" href="{{ asset('Web/Logo/SUSt.png') }}" width="50">
<link rel="stylesheet" href="{{ asset('Web/css/bootstrap.min.css') }}">
<script src="https://kit.fontawesome.com/176b9ccd7c.js" crossorigin="anonymous"></script>
<link href="https://fonts.googleapis.com/css?family=Muli&display=swap" rel="stylesheet">

@yield('styles')
