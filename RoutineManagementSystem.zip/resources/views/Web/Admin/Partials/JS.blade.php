<script src="{{ asset('Web/js/jquery-slim.min.js') }}"></script>
<script src="{{ asset('Web/js/popper.min.js') }}"></script>
<script src="{{ asset('Web/js/bootstrap.min.js')}}"></script>

@yield('scripts')
