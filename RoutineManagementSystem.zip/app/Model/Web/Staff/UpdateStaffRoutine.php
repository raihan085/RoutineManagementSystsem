<?php

namespace App\Model\Web\Staff;

use Illuminate\Database\Eloquent\Model;

class UpdateStaffRoutine extends Model
{
    protected $fillable = [
      'Day',
      'RoomNumber'
    ];
}
