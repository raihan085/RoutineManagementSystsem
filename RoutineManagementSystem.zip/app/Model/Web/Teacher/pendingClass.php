<?php

namespace App\Model\Web\Teacher;

use Illuminate\Database\Eloquent\Model;

class pendingClass extends Model
{
    //
}
