<?php

namespace App\Model\Web\Teacher;

use Illuminate\Database\Eloquent\Model;

class UpdateTeacherRoutine extends Model
{
    protected $fillable = [
      'Day',
      'ShortName'
    ];
}
