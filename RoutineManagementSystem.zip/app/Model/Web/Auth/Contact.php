<?php

namespace App\Model\Web\Auth;

use Illuminate\Database\Eloquent\Model;

class Contact extends Model
{
    //
}
