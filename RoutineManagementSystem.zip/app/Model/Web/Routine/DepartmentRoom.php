<?php

namespace App\Model\Web\Routine;

use Illuminate\Database\Eloquent\Model;

class DepartmentRoom extends Model
{
    //
}
