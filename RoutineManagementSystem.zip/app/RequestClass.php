<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RequestClass extends Model
{
    //
}
