<!DOCTYPE html>
<html lang="en">
<head>
  <?php echo $__env->make('Web.Teacher.Partials.CSS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

  <?php echo $__env->make('Web.Teacher.layout.extrateacherNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->yieldContent('body'); ?>

  <br><br><br>
  <?php echo $__env->make('Web.Teacher.Partials.ExtraFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('Web.Teacher.Partials.JS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Teacher/Pages/index.blade.php ENDPATH**/ ?>