<h2>Ok</h2>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Auth/Pages/requestJoin.blade.php ENDPATH**/ ?>