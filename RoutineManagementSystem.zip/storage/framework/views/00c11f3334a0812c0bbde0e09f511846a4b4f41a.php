<!DOCTYPE html>
<html lang="en" dir="ltr">
  <?php echo $__env->make('Web.includes.CSSJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html>

<table class="table table-bordered table-hover">

  <thead>
        <tr>
          <th class="col">Day</th>
          <th class="col">8.00-9.00</th>
          <th class="col">9.00-10.00</th>
          <th class="col">10.00-11.00</th>
          <th class="col">11.00-12.00</th>
          <th class="col">12.00-1.00</th>
          <th class="col">1.00-2.00</th>
          <th class="col">2.00-3.00</th>
          <th class="col">3.00-4.00</th>
          <th class="col">4.00-5.00</th>
        </tr>
  </thead>
        <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td>$day->Day</td>
            <td>$day->EightToNine</td>
            <td>$day->NineToTen</td>
            <td>$day->TenToEleven</td>
            <td>$day->ElevenToTwelve</td>
            <td>$day->TweleveToOne</td>
            <td>$day->OneToTwo</td>
            <td>$day->TwoToThree</td>
            <td>$day->ThreeToFour</td>
            <td>$day->FourToFive</td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <tbody>
  </tbody>
</table>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Student/StudentBatchShow.blade.php ENDPATH**/ ?>