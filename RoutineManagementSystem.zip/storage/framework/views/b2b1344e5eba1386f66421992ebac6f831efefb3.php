<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    </head>

  <body>

    <div class="container m-3 p-3">

    <table class="table table-bordered table-hover">
      <thead class="thead-light">
        <tr>
          <th>Day</th>
          <th>Name</th>
          <th>8.00-9.00</th>
          <th>9.00-10.00</th>
          <th>10.00-11.00</th>
          <th>11.00-12.00</th>
          <th>12.00-1.00</th>
          <th>1.00-2.00</th>
          <th>2.00-3.00</th>
          <th>3.00-4.00</th>
          <th>4.00-5.00</th>
        </tr>
      </thead>

      <tbody>
          <?php $Date = 'null'; ?>
          <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <?php if($Date == $day->Day): ?>
              <td></td>
              <td><?php echo e($day->ShortName); ?></th>
              <td> <?php echo e($day->EightToNine); ?></td>
              <td> <?php echo e($day->NineToTen); ?></td>
              <td> <?php echo e($day->TenToEleven); ?></td>
              <td> <?php echo e($day->ElevenToTwelve); ?></td>
              <td> <?php echo e($day->TwelveToOne); ?></td>
              <td> <?php echo e($day->OneToTwo); ?></td>
              <td> <?php echo e($day->TwoToThree); ?></td>
              <td> <?php echo e($day->ThreeToFour); ?></td>
              <td> <?php echo e($day->FourToFive); ?></td>
              <?php else: ?>
              <td><?php echo e($day->Day); ?></td>
              <td><?php echo e($day->ShortName); ?></th>
              <td> <?php echo e($day->EightToNine); ?></td>
              <td> <?php echo e($day->NineToTen); ?></td>
              <td> <?php echo e($day->TenToEleven); ?></td>
              <td> <?php echo e($day->ElevenToTwelve); ?></td>
              <td> <?php echo e($day->TwelveToOne); ?></td>
              <td> <?php echo e($day->OneToTwo); ?></td>
              <td> <?php echo e($day->TwoToThree); ?></td>
              <td> <?php echo e($day->ThreeToFour); ?></td>
              <td> <?php echo e($day->FourToFive); ?></td>
              <?php $Date = $day->Day; ?>
              <?php endif; ?>

          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </tbody>
    </table>
</div>
  </body>
</html>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Teacher/RoutineDay.blade.php ENDPATH**/ ?>