<!-- navbar -->
<nav class="navbar navbar-expand-md bg-light navbar-dark">

  <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="collapsibleNavbar">


    <div class="container-fluid">
      <div class="row mt-2">

        <!-- top navbar -->
          <?php echo $__env->make('Web.Admin.layout.topNavBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end of top navbar -->

        <!-- sidebar -->
         <?php echo $__env->make('Web.Admin.layout.sideBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end of side bar -->

        <?php echo $__env->yieldContent('body'); ?>

      </div>

    </div>
  </div>
</div>
<!-- end of navbar -->
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Admin/layout/AdminnavBar.blade.php ENDPATH**/ ?>