<div>
<nav class="navbar navbar-expand-md bg-dark navbar-dark mb-5">
  <div class="container">
    <a href="<?php echo e(route('user.index')); ?>" class="navbar-brand">
      <img src="<?php echo e(asset('Web/Logo/SUST.png')); ?>" alt="LOGO" width="50">
      <span class="text">Shahjalal University of Science & Technology</span>
    </a>
    <button type="button" name="button" class="navbar-toggler navbar-toggler-right" data-toggle="collapse" data-target="#LogInnavbarNav" >
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="LogInnavbarNav">

  <?php if(Request::is('/') || Request::is('joinus') || Request::is('contact')||Request::is('contact')): ?>)
        <ul class="nav navbar-nav ml-auto">
          <li class="nav-item">
            <a href="<?php echo e(route('user.index')); ?>" class="nav-link">Log In</a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('user.join.us')); ?>" class="nav-link">Join Us!</a>
          </li>
          <li class="nav-item">
            <a href="<?php echo e(route('user.contact')); ?>" class="nav-link">Contact</a>
          </li>
        </ul>
     <?php elseif(Request::is('request')): ?>
        <?php echo $__env->yieldContent('body'); ?>
    <?php endif; ?>
    </div>
  </div>
</nav>
</div>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Auth/Layouts/LogInNav.blade.php ENDPATH**/ ?>