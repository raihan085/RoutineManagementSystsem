    

    <?php $__env->startSection('body'); ?>

            <div class="container m-3 p-2">
              <table class="table table-bordered table-hover m-3">

                <div class="">
                    <!-- semester routine -->
                </div>

                <!-- batch routine -->
                <thead class="thead-light">
                      <tr>
                        <th>Day</th>
                        <th>8.00-9.00</th>
                        <th>9.00-10.00</th>
                        <th>10.00-11.00</th>
                        <th>11.00-12.00</th>
                        <th>12.00-1.00</th>
                        <th>1.00-2.00</th>
                        <th>2.00-3.00</th>
                        <th>3.00-4.00</th>
                        <th>4.00-5.00</th>
                      </tr>
                </thead>

                <tbody>

                    <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope="row"> <?php echo e($day->Day); ?></th>
                      <td> <?php echo e($day->EightToNine); ?></td>
                      <td> <?php echo e($day->NineToTen); ?></td>
                      <td> <?php echo e($day->TenToEleven); ?></td>
                      <td> <?php echo e($day->ElevenToTwelve); ?></td>
                      <td> <?php echo e($day->TwelveToOne); ?></td>
                      <td> <?php echo e($day->OneToTwo); ?></td>
                      <td> <?php echo e($day->TwoToThree); ?></td>
                      <td> <?php echo e($day->ThreeToFour); ?></td>
                      <td> <?php echo e($day->FourToFive); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>
              <!-- end of batch routine -->
            </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Web.Student.Pages.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Student/Pages/RoutineBatch.blade.php ENDPATH**/ ?>