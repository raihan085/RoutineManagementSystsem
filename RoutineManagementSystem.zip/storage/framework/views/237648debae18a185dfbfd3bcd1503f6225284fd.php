<script src="<?php echo e(asset('Web/js/jquery-slim.min.js')); ?>"></script>
<script src="<?php echo e(asset('Web/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('Web/js/bootstrap.min.js')); ?>"></script>

<?php echo $__env->yieldContent('scripts'); ?>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Admin/Partials/JS.blade.php ENDPATH**/ ?>