<!DOCTYPE html>
<html lang="en">
<head>
  <?php echo $__env->make('Web.Staff.Partials.CSS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
  <?php echo $__env->make('Web.Staff.layout.staffNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->yieldContent('body'); ?>

  <br><br><br>
  <?php echo $__env->make('Web.Staff.Partials.ExtraFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('Web.Staff.Partials.JS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Staff/Pages/index.blade.php ENDPATH**/ ?>