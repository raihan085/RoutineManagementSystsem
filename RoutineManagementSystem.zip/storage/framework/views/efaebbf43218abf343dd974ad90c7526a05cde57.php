<div class="card col-lg-3 col-md-2 mx-3 my-5 bg-dark text-dark">
  <div class="card-header">
    Dashborad
  </div>
  <div class="card-body">
    <ul>
      <li>
        <a href="#" class="btn btn-secondary mt-2">Full Routine</a>
      </li>
      <li>
        <a href="#" class="btn btn-secondary mt-2">Request</a>
      </li>
      <li>
        <a href="#" class="btn btn-secondary mt-2">Inbox</a>
      </li>
      <li>
        <a href="#" class="btn btn-secondary mt-2">Routine</a>
        <ul>
          <li>
            <a href="#" class="btn btn-secondary mt-2">Add Class</a>
          </li>
          <li>
            <a href="#" class="btn btn-secondary mt-2">Edit Class</a>
          </li>
        </ul>
      </li>

      <li>
        <a href="#" class="btn btn-secondary mt-2">Syllabus</a>
        <ul>
          <li>
            <a href="#" class="btn btn-secondary mt-2">Add Course</a>
          </li>
          <li>
            <a href="#" class="btn btn-secondary mt-2">Edit Course</a>
          </li>
          <li>
            <a href="#" class="btn btn-secondary mt-2">Delete Course</a>
          </li>
        </ul>
      </li>
      <li>
        <a href="#" class="btn btn-secondary mt-2">Add Room</a>
      </li>
      <li>
        <a href="#" class="btn btn-secondary mt-2">Add Routine</a>
      </li>
    </ul>
  </div>

</div>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Admin/layout/testSidebar.blade.php ENDPATH**/ ?>