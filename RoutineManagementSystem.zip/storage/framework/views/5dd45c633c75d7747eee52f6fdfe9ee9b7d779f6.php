<?php $__env->startSection('body'); ?>
    <div class="col-lg-9 col-md-9 m-3 p-3">

    <table class="table  table-hover m-5 table-bordered table-sm">
      <thead class="thead-light">
        <tr>
          <th scope="col">Day</th>
          <th scope="col">Name</th>
          <th scope="col">8.00-9.00</th>
          <th scope="col">9.00-10.00</th>
          <th scope="col">10.00-11.00</th>
          <th scope="col">11.00-12.00</th>
          <th scope="col">12.00-1.00</th>
          <th scope="col">1.00-2.00</th>
          <th scope="col">2.00-3.00</th>
          <th scope="col">3.00-4.00</th>
          <th scope="col">4.00-5.00</th>
        </tr>
      </thead>

      <tbody>
          <?php $Date = 'null'; ?>
          <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <?php if($Date == $day->Day): ?>
              <td></td>
              <th scope="row"><?php echo e($day->ShortName); ?></th>
              <td> <?php echo e($day->EightToNine); ?></td>
              <td> <?php echo e($day->NineToTen); ?></td>
              <td> <?php echo e($day->TenToEleven); ?></td>
              <td> <?php echo e($day->ElevenToTwelve); ?></td>
              <td> <?php echo e($day->TwelveToOne); ?></td>
              <td> <?php echo e($day->OneToTwo); ?></td>
              <td> <?php echo e($day->TwoToThree); ?></td>
              <td> <?php echo e($day->ThreeToFour); ?></td>
              <td> <?php echo e($day->FourToFive); ?></td>
              <?php else: ?>
              <th scope="row"><?php echo e($day->Day); ?></th>
              <th scope="row"><?php echo e($day->ShortName); ?></th>
              <td> <?php echo e($day->EightToNine); ?></td>
              <td> <?php echo e($day->NineToTen); ?></td>
              <td> <?php echo e($day->TenToEleven); ?></td>
              <td> <?php echo e($day->ElevenToTwelve); ?></td>
              <td> <?php echo e($day->TwelveToOne); ?></td>
              <td> <?php echo e($day->OneToTwo); ?></td>
              <td> <?php echo e($day->TwoToThree); ?></td>
              <td> <?php echo e($day->ThreeToFour); ?></td>
              <td> <?php echo e($day->FourToFive); ?></td>
              <?php $Date = $day->Day; ?>
              <?php endif; ?>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Web.Admin.Pages.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Admin/Pages/Routine/fullRoutine.blade.php ENDPATH**/ ?>