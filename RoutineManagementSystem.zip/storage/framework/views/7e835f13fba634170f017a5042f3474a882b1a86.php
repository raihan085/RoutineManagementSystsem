<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Routine Management System</title>
  <link rel="stylesheet" href="Web/css/bootstrap.min.css">
  <script src="https://kit.fontawesome.com/176b9ccd7c.js" crossorigin="anonymous"></script>
  <link href="https://fonts.googleapis.com/css?family=Muli&display=swap" rel="stylesheet">

</head>


<script src="Web/js/jquery-slim.min.js"></script>
<script src="Web/js/popper.min.js"></script>
<script src="Web/js/bootstrap.min.js"></script>
</html>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/includes/CSSJS.blade.php ENDPATH**/ ?>