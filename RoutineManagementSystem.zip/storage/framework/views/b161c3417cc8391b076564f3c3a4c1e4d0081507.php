<!DOCTYPE html>
<html lang="en">
<head>
  <?php echo $__env->make('Web.includes.CSSJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>


<div class="">
  <nav class="navbar navbar-expand-md navbar-light bg-light">
    <a class="navbar-brand" href="<?php echo e(URL::to('/teacher')); ?>">
      <img src="Web\Logo\SUST.png" alt="LOGO" width="50">
      <span class="bg-light">Shahjala University of Science & Technology</span>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="<?php echo e(URL::to('staff')); ?>">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(URL::to('staff/FullRoutine')); ?>">Full Routine</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(URL::to('staff/Room/304')); ?>">My Routine</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(URL::to('staff/Day')); ?>">Day Routine</a>
        </li>
      </ul>

        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Name
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="<?php echo e(URl::to('my\profile')); ?>">My Profile</a>
              <a class="dropdown-item" href="#">Log Out</a>
              <a class="dropdown-item" href="#">Password Change</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="<?php echo e(URL::to('contact\admin')); ?>">Contact</a>
            </div>
          </li>
        </ul>

    </div>
  </nav>
</div>

<main>
  <?php echo $__env->yieldContent('content'); ?>
</main>


<?php echo $__env->make('Web.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</body>
</html>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Staff/staffNavbar.blade.php ENDPATH**/ ?>