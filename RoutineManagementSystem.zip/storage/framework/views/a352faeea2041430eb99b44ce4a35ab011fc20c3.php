<?php $__env->startSection('body'); ?>

<!-- curd banate hobe -->

<div class="col-lg-9 col-md-9 mx-2 mt-5">
  <table class="table table-bordered table-hover table-sm">
    <thead class="thead bg-secondary">
      <th scope="col">Full Name</th>
      <th scope="col">ShortName</th>
      <th scope="col">Registration Id</th>
      <th scope="col">Type</th>
      <th scope="col">Email</th>
      <th scope="col">Designation</th>
      <th scope="col">Session</th>
      <th scope="col">Section</th>
      <th scope="col">PhoneNumber</th>
      <th scope="col">Photo</th>
      <th scope="col">Action</th>
    </thead>

    <tbody>
        <?php $__currentLoopData = $req; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reqs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($reqs->FullName); ?></td>
          <td><?php echo e($reqs->ShortName); ?></td>
          <td><?php echo e($reqs->RegistrationNumber); ?></td>
          <td><?php echo e($reqs->Type); ?></td>
          <td><?php echo e($reqs->Email); ?></td>
          <td><?php echo e($reqs->Designation); ?></td>
          <td><?php echo e($reqs->Session); ?></td>
          <td><?php echo e($reqs->Section); ?></td>
          <td><?php echo e($reqs->PhoneNumber); ?></td>
          <td><?php echo e(asset($reqs->Photo)); ?></td>
          <td>
            <form action ="<?php echo e(route('admin.user.request.accept')); ?> "method="post">
              <?php echo csrf_field(); ?>
              <button type="submit" name="accept" value="<?php echo e($reqs->RegistrationNumber); ?>" class="btn btn-primary m-2">Accept</button>
            </form>
            <form action="<?php echo e(route('admin.user.request.delete')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <button type="submit" name="delete" value="<?php echo e($reqs->RegistrationNumber); ?>" class="btn btn-danger m-2">Delete</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Web.Admin.Pages.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Admin/Pages/RequestAccepted.blade.php ENDPATH**/ ?>