<!DOCTYPE html>
<html lang="en">

<head>
  <?php echo $__env->make('Web.Auth.Partials.CSS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

<?php echo $__env->make('Web.Auth.Layouts.LogInNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(Request::is('/')): ?>
  <?php echo $__env->make('Web.Auth.includes.LogInSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(Request::is('request')): ?>
  <?php echo $__env->make('Web.Auth.includes.LogIntext', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if(Request::is('contact')||Request::is('contact')): ?>
  <?php echo $__env->yieldContent('contact'); ?>
<?php endif; ?>

<br><br>
<?php echo $__env->make('Web.Auth.Partials.ExtraFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('Web.Auth.Partials.JS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Auth/Pages/indexLogIn.blade.php ENDPATH**/ ?>