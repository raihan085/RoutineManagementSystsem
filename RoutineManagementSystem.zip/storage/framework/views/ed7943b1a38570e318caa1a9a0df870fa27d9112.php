<!-- navbar -->
<nav class="navbar navbar-expand-md bg-dark navbar-dark">

  <button class="navbar-toggler ml-auto" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="collapsibleNavbar">

    <div class="container-fluid">

      <div class="row">
        <!-- sidebar -->
        <div class="col-lg-3 sidebar">
          <a href="#" class="navbar-brand text-white d-block mx-auto text-center py-3 mb-4 bottom-border">
            <img src="Web/Logo/SUST.png" alt="LOGO" width="50">
          </a>
          <div class="bottom-border pb-3">
            <img src="Web/Pic/Admin/SaifSir.jpg" width="50" class="rounded-circle mr-3">
            <a href="#" class="text-white">Saiful Saif</a>
          </div>

          <ul class="navbar-nav flex-column mt-4">
            <li class="nav-item sidebar-link">
              <a href="#" class="nav-link text-white p-3">
                <i class="fas fa-home text-light fa-lg mr-3"></i>Dashborad
              </a>
            </li>
            <li class="nav-item sidebar-link">
              <a href="#" class="nav-link text-white p-3">
                <i class="fas fa-home text-light fa-lg mr-3"></i>Full Routine
              </a>
            </li>
            <li class="nav-item sidebar-link">
              <a href="#" class="nav-link text-white p-3">
                <i class="fas fa-users text-light fa-lg mr-3"></i>Request
              </a>
            </li>
            <li class="nav-item sidebar-link">
              <a href="#" class="nav-link text-white p-3">
                <i class="fas fa-inbox text-light fa-lg mr-3"></i>Inbox
              </a>
            </li>
            <li class="nav-item sidebar-link">
              <a href="#" class="nav-link text-white p-3">
                <i class="fas fa-plus text-light fa-lg mr-3"></i>Add Routine
              </a>
            </li>
            <li class="nav-item sidebar-link">
              <a href="UploadRoutine" class="nav-link text-white p-3">
                <i class="fas fa-plus text-light fa-lg mr-3"></i>Add Class
              </a>
            </li>

            <li class="nav-item sidebar-link">
              <a href="#" class="nav-link text-white p-3">
                <i class="fas fa-plus text-light fa-lg mr-3"></i>Add Course
              </a>
            </li>
            <li class="nav-item sidebar-link">
              <a href="#" class="nav-link text-white p-3">
                <i class="fas fa-edit text-light fa-lg mr-3"></i>Edit Course
              </a>
            </li>
            <li class="nav-item sidebar-link">
              <a href="#" class="nav-link text-white p-3">
                <i class="fas fa-trash-alt text-light fa-lg mr-3"></i>Delete Course
              </a>
            </li>
            <li class="nav-item sidebar-link">
              <a href="#" class="nav-link text-white p-3">
                <i class="fas fa-trash-alt text-light fa-lg mr-3"></i>Delete Routine
              </a>
            </li>
            <li class="nav-item sidebar-link">
              <a href="#" class="nav-link text-white p-3">
                <i class="fas fa-trash-alt text-light fa-lg mr-3"></i>Delete Class
              </a>
            </li>
            <li class="nav-item sidebar-link">
              <a href="#" class="nav-link text-white p-3">
                <i class="fas fa-user-minus text-light fa-lg mr-3"></i>Delete Account
              </a>
            </li>
          </ul>

        </div>
        <!-- end of sidebar -->

        <!-- topnav -->
        <div class="col-lg-9 ml-auto bg-dark py-2">
          <div class="row">
            <div class="col-md-4">
              <h4 class="text-light text-uppercase mb-0">Dashborad</h4>
            </div>
            <!-- add search button -->
            <div class="col-md-5">
              <form class="" action="#" method="post">
                <div class="input-group">
                  <input type="text" name="" value="" class="form-control" placeholder="Search">
                  <button type="button" name="button" class="btn btn-white">
                    <i class="fas fa-search text-danger"></i>
                  </button>
                </div>
              </form>
            </div>
            <!-- end of search button -->
            <!-- add icon -->
            <div class="col-md-3">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <a href="#" class="nav-link">
                    <i class="fas fa-bell"></i>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="#" class="nav-link">
                    <i class="fas fa-user-circle">
                    </i>
                  </a>
                </li>
                <li class="nav-item">
                  <a href="#" class="nav-link">
                    <i class="fas fa-"></i>
                  </a>
                </li>
              </ul>
            </div>
            <!-- end of icon -->
          </div>
        </div>
        <!-- end of topnav -->
      </div>
    </div>

  </div>
</div>
<!-- end of navbar -->
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Admin/LeftBody.blade.php ENDPATH**/ ?>