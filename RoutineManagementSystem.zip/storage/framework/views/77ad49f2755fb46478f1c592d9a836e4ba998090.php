<?php $__env->startSection('content'); ?>

    <div class="container m-3 p-3">
      <table class="table table-bordered table-hover m-5">
        <thead class="thead-dark">
          <tr>
            <th scope="col">Day</th>
            <th scope="col">8.00-9.00</th>
            <th scope="col">9.00-10.00</th>
            <th scope="col">10.00-11.00</th>
            <th scope="col">11.00-12.00</th>
            <th scope="col">12.00-1.00</th>
            <th scope="col">1.00-2.00</th>
            <th scope="col">2.00-3.00</th>
            <th scope="col">3.00-4.00</th>
            <th scope="col">4.00-5.00</th>
          </tr>
        </thead>

        <tbody>

            <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
              <th scope="row"><?php echo e($day->Day); ?></th>
              <td> <?php echo e($day->EightToNine); ?></td>
              <td> <?php echo e($day->NineToTen); ?></td>
              <td> <?php echo e($day->TenToEleven); ?></td>
              <td> <?php echo e($day->ElevenToTwelve); ?></td>
              <td> <?php echo e($day->TwelveToOne); ?></td>
              <td> <?php echo e($day->OneToTwo); ?></td>
              <td> <?php echo e($day->TwoToThree); ?></td>
              <td> <?php echo e($day->ThreeToFour); ?></td>
              <td> <?php echo e($day->FourToFive); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Web.Staff.staffNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Staff/RoutineRoom.blade.php ENDPATH**/ ?>