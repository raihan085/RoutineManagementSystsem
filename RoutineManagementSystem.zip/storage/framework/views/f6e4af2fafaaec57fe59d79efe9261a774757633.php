<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title>Routine Management System</title>
<link rel="icon" href="<?php echo e(asset('Web/Logo/SUSt.png')); ?>" width="50">
<link rel="stylesheet" href="<?php echo e(asset('Web/css/bootstrap.min.css')); ?>">
<script src="https://kit.fontawesome.com/176b9ccd7c.js" crossorigin="anonymous"></script>
<link href="https://fonts.googleapis.com/css?family=Muli&display=swap" rel="stylesheet">

<?php echo $__env->yieldContent('styles'); ?>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Auth/Partials/CSS.blade.php ENDPATH**/ ?>