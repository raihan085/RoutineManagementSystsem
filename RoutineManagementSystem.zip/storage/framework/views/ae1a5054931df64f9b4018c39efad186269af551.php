<?php $__env->startSection('contact'); ?>
<div class="container">
  <form action="<?php echo e(route('user.contact')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="name">Full Name</label>
      <input type="text" name="Name" id="name" class="form-control">
    </div>
    <div class="form-group">
      <label for="email">Email</label>
      <input type="email" name="Email" id = "email" class="form-control">
    </div>

    <div class="form-group">
      <label for="">Type</label>
      <select class="form-control" name="type">
        <option>Student</option>
        <option>Teacher</option>
        <option>Office Staff</option>
        <option>Others</option>
      </select>
    </div>

    <div class="form-group">
      <label for="message">Message</label>
      <input type="text" name="Message" id="message" class="form-control" height="150">
    </div>

    <button type="submit" class="form-control btn btn-primary">Submit</button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Web.Auth.Pages.indexLogIn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Auth/Pages/Contact.blade.php ENDPATH**/ ?>