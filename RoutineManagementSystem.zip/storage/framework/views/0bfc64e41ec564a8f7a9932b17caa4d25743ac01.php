<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Routien Management System</title>
  <link rel="stylesheet" href="Web/css/bootstrap.min.css">
</head>
<body>

  <div class="row">
    <div class="continer col-10">
      <div class="card">
        <div class="card-header">
            Add Class with Session and Semester
        </div>
        <div class="card-body">
          <div class="form">

            <div class="row m-3">

              <div class="form-group col-3">
                <label for="day">Day</label>
                <select class="form-control form-control-sm" id="day">
                  <option>Sunday</option>
                  <option>Monday</option>
                  <option>Tuesday</option>
                  <option>Wednesday</option>
                  <option>Thursday</option>
                </select>
              </div>

              <div class="form-group col-3">
                <label for="session">Session</label>
                <select id="session" class="form-control form-control-sm">
                  <option>2015-16</option>
                  <option>2016-17</option>
                  <option>2017-18</option>
                  <option>2018-19</option>
                  <option>2019-20</option>
                </select>
              </div>

              <div class="form-group col-3">
                <label for="semester">Semester</label>
                <select class="form-control form-control-sm" id="semester">
                  <option>1/1</option>
                  <option>1/2</option>
                  <option>2/1</option>
                  <option>2/2</option>
                  <option>3/1</option>
                  <option>3/2</option>
                  <option>4/1</option>
                  <option>4/2</option>
                </select>
              </div>

              <div class="form-group col-3">
                <label for="section">Section</label>
                <select class="form-control form-contorl-sm" id="section">
                  <option>A</option>
                  <option>B</option>
                </select>
              </div>
            </div>


              <div class="row m-3">
                <div class="col-3">
                  <label for="EightToNine">Time: </label>
                  <input type="text" id="EightToNine" placeholder="8.00-9.00" class="form-control form-control-sm">
                </div>
                  <div class="col-3">
                    <label for="CourseCode">Course Code: </label>
                    <input type="text" id="CourseCode" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="TeacherName">Teacher Name: </label>
                    <input type="text" id="TeacherName" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="RoomNumber">Room Number: </label>
                    <input type="text" id="RoomNumber" class="form-control form-control-sm">
                  </div>
              </div>

              <div class="row m-3">
                <div class="col-3">
                  <label for="NineToTen">Time: </label>
                  <input type="text" id="NineToTen" placeholder="9.00-10.00" class="form-control form-control-sm">
                </div>
                  <div class="col-3">
                    <label for="CourseCode">Course Code: </label>
                    <input type="text" id="CourseCode" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="TeacherName">Teacher Name: </label>
                    <input type="text" id="TeacherName" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="RoomNumber">Room Number: </label>
                    <input type="text" id="RoomNumber" class="form-control form-control-sm">
                  </div>
              </div>

              <div class="row m-3">
                <div class="col-3">
                  <label for="TenToEleven">Time: </label>
                  <input type="text" id="TenToEleven" placeholder="10.00-11.00" class="form-control form-control-sm">
                </div>
                  <div class="col-3">
                    <label for="CourseCode">Course Code: </label>
                    <input type="text" id="CourseCode" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="TeacherName">Teacher Name: </label>
                    <input type="text" id="TeacherName" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="RoomNumber">Room Number: </label>
                    <input type="text" id="RoomNumber" class="form-control form-control-sm">
                  </div>
              </div>

              <div class="row m-3">
                <div class="col-3">
                  <label for="ElevenToTwleve">Time: </label>
                  <input type="text" id="ElevenToTwleve" placeholder="11.00-12.00" class="form-control form-control-sm">
                </div>
                  <div class="col-3">
                    <label for="CourseCode">Course Code: </label>
                    <input type="text" id="CourseCode" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="TeacherName">Teacher Name: </label>
                    <input type="text" id="TeacherName" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="RoomNumber">Room Number: </label>
                    <input type="text" id="RoomNumber" class="form-control form-control-sm">
                  </div>
              </div>

              <div class="row m-3">
                <div class="col-3">
                  <label for="TwleveToOne">Time: </label>
                  <input type="text" id="TwleveToOne" placeholder="12.00-1.00" class="form-control form-control-sm">
                </div>
                  <div class="col-3">
                    <label for="CourseCode">Course Code: </label>
                    <input type="text" id="CourseCode" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="TeacherName">Teacher Name: </label>
                    <input type="text" id="TeacherName" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="RoomNumber">Room Number: </label>
                    <input type="text" id="RoomNumber" class="form-control form-control-sm">
                  </div>
              </div>

              <div class="row m-3">
                <div class="col-3">
                  <label for="OneToTwo">Time: </label>
                  <input type="text" id="OneToTwo" placeholder="1.00-2.00" class="form-control form-control-sm">
                </div>
                  <div class="col-3">
                    <label for="CourseCode">Course Code: </label>
                    <input type="text" id="CourseCode" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="TeacherName">Teacher Name: </label>
                    <input type="text" id="TeacherName" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="RoomNumber">Room Number: </label>
                    <input type="text" id="RoomNumber" class="form-control form-control-sm">
                  </div>
              </div>

              <div class="row m-3">
                <div class="col-3">
                  <label for="TwoToThree">Time: </label>
                  <input type="text" id="TwoToThree" placeholder="2.00-3.00" class="form-control form-control-sm">
                </div>
                  <div class="col-3">
                    <label for="CourseCode">Course Code: </label>
                    <input type="text" id="CourseCode" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="TeacherName">Teacher Name: </label>
                    <input type="text" id="TeacherName" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="RoomNumber">Room Number: </label>
                    <input type="text" id="RoomNumber" class="form-control form-control-sm">
                  </div>
              </div>

              <div class="row m-3">
                <div class="col-3">
                  <label for="ThreeToFour">Time: </label>
                  <input type="text" id="ThreeToFour" placeholder="3.00-4.00" class="form-control form-control-sm">
                </div>
                  <div class="col-3">
                    <label for="CourseCode">Course Code: </label>
                    <input type="text" id="CourseCode" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="TeacherName">Teacher Name: </label>
                    <input type="text" id="TeacherName" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="RoomNumber">Room Number: </label>
                    <input type="text" id="RoomNumber" class="form-control form-control-sm">
                  </div>
              </div>

              <div class="row m-3">
                <div class="col-3">
                  <label for="FourToFive">Time: </label>
                  <input type="text" id="FourToFive" placeholder="4.00-5.00" class="form-control form-control-sm">
                </div>
                  <div class="col-3">
                    <label for="CourseCode">Course Code: </label>
                    <input type="text" id="CourseCode" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="TeacherName">Teacher Name: </label>
                    <input type="text" id="TeacherName" class="form-control form-control-sm">
                  </div>
                  <div class="col-3">
                    <label for="RoomNumber">Room Number: </label>
                    <input type="text" id="RoomNumber" class="form-control form-control-sm">
                  </div>
              </div>

      <div class="form-group ml-4">
        <a href="#" class="btn btn-primary">Submit</a>
      </div>

          </div>
        </div>
      </div>
    </div>
  </div>

</body>
</html>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Admin/RoutineAdd.blade.php ENDPATH**/ ?>