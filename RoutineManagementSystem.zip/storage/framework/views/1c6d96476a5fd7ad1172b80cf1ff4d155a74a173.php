<!DOCTYPE html>
<html lang="en">
<head>
  <?php echo $__env->make('Web.includes.CSSJS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <link rel="stylesheet" href="Web/css/Admin/style.css">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.12.1/css/all.css" integrity="sha384-v8BU367qNbs/aIZIxuivaU55N5GPF89WBerHoGA4QTcbUjYiLQtKdrfXnqAcXyTv" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/css?family=Atma|Muli&display=swap" rel="stylesheet">
</head>
<body>

  <?php echo $__env->make('Web.Admin.LeftBody', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Admin/navBar.blade.php ENDPATH**/ ?>