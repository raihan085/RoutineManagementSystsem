<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Routine Management System</title>
  <link rel="stylesheet" href="Web/css/bootstrap.min.css">
</head>
<body>

  <div class="card">
    <div class="card-header">
      Log In
    </div>
    <div class="card-body">
      <form >
        <div class="form-group row text-center">
          <label for="" class="mr-5">Email</label>
          <input type="text" name="" value="">
        </div>

        <div class="form-group row">
          <label for="" class="mr-3">Password</label>
          <input type="text" name="" value="">
        </div>

        <div class="form-group">
          <a href="#" class="btn btn-primary">Submit</a>
        </div>
      </form>
    </div>
  </div>

<script type="Web/js/bootstrap.min.js">

</script>
</body>
</html>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Auth/auth/login.blade.php ENDPATH**/ ?>