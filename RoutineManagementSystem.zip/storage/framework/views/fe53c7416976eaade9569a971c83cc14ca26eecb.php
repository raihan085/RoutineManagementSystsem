<?php $__env->startSection('body'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Web.Admin.Pages.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Admin/Pages/DeleteRoutine.blade.php ENDPATH**/ ?>