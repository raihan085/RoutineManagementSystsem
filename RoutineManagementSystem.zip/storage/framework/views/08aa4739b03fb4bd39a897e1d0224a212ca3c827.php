<?php $__env->startSection('body'); ?>
<div class="col-lg-9 col-md-9 m-5">
  <table class="table table-bordered table-hover">
    <thead class="thead thead-dark">
      <tr>
        <th></th>
        <th>Name</th>
        <th>Email</th>
        <th>Type</th>
        <th>Message</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php $i = 1; ?>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($i); ?></td>
          <td><?php echo e($user->FullName); ?></td>
          <td><?php echo e($user->Email); ?></td>
          <td><?php echo e($user->Type); ?></td>
          <td><?php echo e($user->Message); ?></td>
          <td>
            <form action="<?php echo e(route('admin.inbox.delete')); ?>" method="post">
              <?php echo csrf_field(); ?>
             <button type="submit" class="btn btn-danger" name="Email" value="<?php echo e($user->Email); ?>">Delete</button>
            </form>
          </td>
          <?php $i++; ?>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Web.Admin.Pages.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Admin/Pages/inbox.blade.php ENDPATH**/ ?>