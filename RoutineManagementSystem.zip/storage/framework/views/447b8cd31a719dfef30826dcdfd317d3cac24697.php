<?php $__env->startSection('body'); ?>
<ul class="nav navbar-nav ml-auto">
  <li class="nav-item">
    <a href="<?php echo e(route('user.request.contact')); ?>" class="nav-link">Contact</a>
  </li>
  <li class="nav-item">
    <a href="<?php echo e(route('user.logout')); ?>" class="nav-link">Logout</a>
  </li>
</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Web.Auth.Pages.indexLogIn', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Auth/Pages/requestSignIn.blade.php ENDPATH**/ ?>