<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">

  <link rel="stylesheet" href="Web/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  <title>Routine Management System</title>
</head>
<body>



<?php $__env->startSection('content'); ?>

<?php echo $__env->yieldContent('Content'); ?>
<?php echo $__env->make('Web.Auth.LogInSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- <?php echo $__env->make('Web.includes.LogInSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
<br><br>
<?php echo $__env->make('Web.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<script type="Web/js/jquery-slim.min.js"></script>
<script type="Web/js/popper.min.js"></script>
<script type="Web/js/bootstrap.min.js"></script>
</body>

</html>

<?php echo $__env->make('Web.includes.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Auth/LogIn.blade.php ENDPATH**/ ?>