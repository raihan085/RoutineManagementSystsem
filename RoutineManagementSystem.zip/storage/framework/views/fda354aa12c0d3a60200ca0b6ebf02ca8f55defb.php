<?php $__env->startSection('body'); ?>

<div class="container m-5">
    <form action="<?php echo e(route('request.class.submit')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <div class="form-group row">
        <label for="day">Day</label>
        <select class="form-control" name="day">
          <option>Sunday</option>
          <option>Monday</option>
          <option>Tuesday</option>
          <option>Wednesday</option>
          <option>Thursday</option>
        </select>
      </div>
      <div class="form-group row">
        <label for="courseCode">Course Code</label>
        <input type="text" name="CourseCode" id="courseCode" class="form-control">
      </div>
      <div class="form-group row">
        <label for="section">Section</label>
        <select class="form-control" name="Section" id="section">
          <option>A</option>
          <option>B</option>
        </select>
      </div>
      <div class="form-group row">
        <label for="time">Time</label>
        <select class="form-control" name="Time" id="time">
          <option value="EightToNine">8.00-9.00</option>
          <option value="NineToTen">9.00-10.00</option>
          <option value="TenToEleven">10.00-11.00</option>
          <option value="ElevenToTwelve">11.00-12.00</option>
          <option value="TwelveToOne">12.00-1.00</option>
          <option value="OneToTwo">1.00-2.00</option>
          <option value="TwoToThree">2.00-3.00</option>
          <option value="ThreeToFour">3.00-4.00</option>
          <option value="FourToFive">4.00-5.00</option>
        </select>
      </div>
      <button type="submit" class="btn btn-primary">Submit</button>
    </form>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Web.Teacher.Pages.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Teacher/Pages/RequestedClassTime.blade.php ENDPATH**/ ?>