<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <div class="container">
    <a href="#" class="navbar-brand">
      <img src="Web/Logo/SUST.png" alt="LOGO" style="width:75px;">
    </a>
    <button type="button" name="button" class="navbar-toggler navbar-toggler-right" data-toggle="collapse" data-target="#LogInnavbarNav" >
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="LogInnavbarNav">
      <ul class="nav navbar-nav ml-auto">
        <li class="nav-item">
          <a href="#" class="nav-link">Log In</a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">Join Us!</a>
        </li>
        <li class="nav-item">
          <a href="#" class="nav-link">Contact</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container">
  <?php echo $__env->yieldContent('contain'); ?>
</div>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Layouts/LogInNav.blade.php ENDPATH**/ ?>