<?php $__env->startSection('body'); ?>

  <!-- course search -->
  <div class="col-md-9  col-lg-9 m-5 d-flex-row justify-content-center">
  <!-- end of course search -->

  <!-- edit course -->
  <div class="card col-md-9 mx-3">
      <div class="card-header">
        Delete Course
      </div>

      <div class="card-body">
        <form action="EditCourseSubmit" method="post">
          <?php echo csrf_field(); ?>
            <div class="form-group row">
              <label for="CourseCode" class="col-sm-6 col-form-label">Course Code</label>
              <div class="col-sm-6">
                <input type="text" name="CourseCode" id="CourseCode" class="form-control">
              </div>
            </div>
            <div class="form-group row">
              <label for="CourseName" class="col-sm-6 col-form-label mt-2">Course Name</label>
              <div class="col-sm-6 mt-2">
                <input type="text" name="CourseName" id="CourseName" class="form-control">
              </div>
            </div>
            <button type="submit" class="btn btn-primary mb-2">Submit</button>
        </form>
      </div>

  </div>
  <!-- end of course edit -->
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('Web.Admin.Pages.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Admin/Pages/DeleteCourse.blade.php ENDPATH**/ ?>