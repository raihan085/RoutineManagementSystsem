<!DOCTYPE html>
<html lang="en">
<head>
  <?php echo $__env->make('Web.Admin.Partials.CSS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <link rel="stylesheet" href="<?php echo e(asset('Web/css/Admin/style.css')); ?>">


</head>
<body>

  <?php echo $__env->make('Web.Admin.layout.AdminnavBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('Web.Admin.Partials.JS', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\Users\Raihan\Desktop\CSE Project\RoutineManagementSystem\resources\views/Web/Admin/Pages/index.blade.php ENDPATH**/ ?>